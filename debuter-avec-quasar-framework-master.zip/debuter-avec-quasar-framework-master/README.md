# Débuter avec Quasar Framework

Ce dépôt est une annexe de mon article "Débuter avec Quasar Framework" publié en 2 parties sur Medium.com :

* [Débuter avec Quasar Framework (1/2)](https://medium.com/codeshake/d%C3%A9buter-avec-quasar-framework-1-2-a80d24437ae8)
* [Débuter avec Quasar Framework (2/2)](https://medium.com/codeshake/d%C3%A9buter-avec-quasar-framework-2-2-26545a510878)

Le contient une branche par exemple de code de l'article :
* q-btn
* q-table
* q-carousel
* q-uploader
* q-infinite-scroll-q-pull-to-refresh

## Installation des dépendances
```bash
npm i
```

### Exécution du projet
```bash
npx quasar dev
```
