"use strict";

const utils = {
};

utils.equalJsonByValue = ( json1, json2 ) => {
	let returnValue = false;
	
	let keyJson1 = Object.keys(json1);
	let valueJson1 = Object.values(json1);
	let keyJson2 = Object.keys(json2);
	let valueJson2 = Object.values(json2);

	if ( keyJson1.length === keyJson2.length ) {
		returnValue = true;	
		for( let i=0 ; i<keyJson1.length ; i++ ) {
			if( ! ( keyJson1[i] === keyJson2[i] && valueJson1[i] === valueJson2[i] ) ) {
				returnValue = false;	
				break;
			}
		}	
	}

	return returnValue;
};

utils.isNodeByValueInList = ( json , list ) => {
	let returnValue = false;
	if ( list.length == 0 ) returnValue = false;
	for ( let i = 0 ; i < list.length ; i++ ) {
		if ( list[i].x == json.x && list[i].y == json.y ) {
			returnValue = true;
			break;
		}
	}
	return returnValue;
}

utils.getNodeFromList = ( json , list ) => {
	let returnValue = undefined;
	if ( list.length > 0 ) {
		for ( let i = 0 ; i < list.length ; i++ ) {
			if ( list[i].x == json.x && list[i].y == json.y ) {
				returnValue = list[i];
				break;
			}
		}
	}
	return returnValue;
}