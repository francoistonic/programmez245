class Astar {

    constructor(barrierWallSymbol,map) {

        this.barrierWallSymbol = barrierWallSymbol;
        this.map = map;
        this.path = new Array();

        this.openedList = new Array();
        this.closedList = new Array();
    }

    ////////////////////////////////////////
    // calculer la distance entre 2 noeuds
	////////////////////////////////////////
    distanceFromNodeToNode = (startNode,endNode) => {

		// distance euclidienne	
        return Math.sqrt( (Math.abs(startNode.x - endNode.x)^2) + (Math.abs(startNode.y - endNode.y)^2) );

		// distance de Manhattan
        //return 2 * (Math.abs(endNode.x - startNode.x) + Math.abs(endNode.y - startNode.y));
    }

	//////////////////////////////////////////////////////////
	// qualifier un noeud (renvoie le noeud avec sa qualité) 
	//////////////////////////////////////////////////////////
    setNodeQualityValue = (current,node,end) => {

        let f = this.distanceFromNodeToNode(current,node) + this.distanceFromNodeToNode(node,end);
        
        return {
            f : f
        }
    }

	//////////////////////////////////////////
	// placer un noeud dans la liste ouverte
	//////////////////////////////////////////
    pushNodeToOpenedList = (node) => {
        this.openedList.push(node);
    }

	/////////////////////////////////////////
	// placer un noeud dans la liste fermée
	/////////////////////////////////////////
    pushNodeToClosedList = (node) => {
        this.closedList.push(node);
    }

	/////////////////////////////////////////    
	// retirer un noeud de la liste ouverte
	/////////////////////////////////////////
    removeNodeFromOpenedList = (node) => {
        let index = this.openedList.indexOf(node);
        if ( index !== -1 ) this.openedList.splice(index,1);
    }

    ///////////////////////////////////////////////////
    // remplacer un noeud par un autre dans une liste
    ///////////////////////////////////////////////////
    replaceNodeByNode = ( replacedNode, nodeToReplace, targetList ) => {
        if ( targetList.length > 0 ) {
            for ( let i = 0 ; i < targetList.length ; i++ ) {
                if ( targetList[i].x === replacedNode.x && targetList[i].y === replacedNode.y ) {
                    targetList[i] = nodeToReplace;
                    break;
                }
            }
        }
    }

    /////////////////////////////////////////////////////////
    // remplacer un noeud par un autre dans la liste fermée
    /////////////////////////////////////////////////////////
    replaceNodeByNodeInOpenedList = ( replacedNode, nodeToReplace ) => {
        this.replaceNodeByNode(replacedNode, nodeToReplace, this.openedList);
    }

    //////////////////////////////////////////////////////////////////////////////////////////
    // rechercher le meilleur noeud dans la liste ouverte (celui ayant la meilleure qualité)
	// le placer dans la liste fermée
	// le retirer de la liste ouverte   
	//////////////////////////////////////////////////////////////////////////////////////////
    searchBestNodeInOpenedListAndPushItToClosedList = () => {
        let bestCurrentNode = {
            f : 1000
        };
        
        for ( let node of this.openedList )  {
            if (node.f < bestCurrentNode.f ) {
                bestCurrentNode = node;
            }
        }
    
		this.pushNodeToClosedList(bestCurrentNode);
		this.openedList.splice(this.openedList.indexOf(bestCurrentNode),1);
    
        return bestCurrentNode;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // lister les noeuds à explorer
	// les placer dans la liste ouverte 
	// si nécessaire (meilleure qualité), les mettre à jour s'ils sont déjà dans la liste ouverte 
    ///////////////////////////////////////////////////////////////////////////////////////////////	
	listNextCellsAndPushToOpenedList = (current,map,player,lastBestNode) => {
	  
        let i = 0;
		
		// lister les noeuds à explorer
        let nextCells = [];
        if ( current.y-1 >= 0 ) {
            nextCells[ i ] = [current.x,current.y-1];
            i++;
        }
    
        if ( current.x+1 < 20 ) {
            nextCells[ i ] = [current.x+1,current.y];
            i++;
        }
    
        if ( current.y+1 < 20 ) {
            nextCells[ i ] = [current.x,current.y+1];
            i++;
        }
    
        if ( current.x-1 >= 0 ) {
            nextCells[ i ] = [current.x-1,current.y];
        }
    
		// pour chaque noeud à explorer
        for ( i in nextCells )  {
            let line = nextCells[ i ];	
            let node = this.setNodeQualityValue({x:current.x,y:current.y},lastBestNode,{x:player.x,y:player.y});
            node.x = line[0];
            node.y = line[1];
    
			// exclure ceux qui sont des obstacles (mur...)
            if ( map[ line[1] ][ line[0] ] !== this.barrierWallSymbol 
                && !utils.isNodeByValueInList( node , this.closedList ) ) {
    
				// pour les autres
				// si le noeud est déjà dans la liste ouverte
                if ( utils.isNodeByValueInList( node , this.openedList ) ) {
                    // comparer les valeurs des 2 noeuds 
					// échanger les valeurs si le noeud à explorer est de meilleur qualité
                    let existingNodeInOpenedList = utils.getNodeFromList( node , this.openedList );

                    if ( existingNodeInOpenedList.f < node.f ) {
                        node.parent = current;
                        this.replaceNodeByNodeInOpenedList(existingNodeInOpenedList,node);
                    }
    
                } else { // sinon placer le noeud directement dans la liste ouverte
                    this.pushNodeToOpenedList({
                        x : node.x,
                        y : node.y,
                        f : node.f,
                        parent : current
                    });
                }
                
    
            }
            
        }
    }

    searchPath = (nodeFrom, nodeTo) => {

        // calculer la qualité du premier noeud (noeud de départ)
        let node = this.setNodeQualityValue({x:nodeFrom.x,y:nodeFrom.y},{x:nodeFrom.x,y:nodeFrom.y},{x:nodeTo.x,y:nodeTo.y});
        
        // placer le noeud qualifié dans la liste fermée
        let lastBestNode = {
            x : nodeFrom.x,
            y : nodeFrom.y,
            f : node.f,
            parent : undefined
        }
        this.pushNodeToClosedList(lastBestNode);
       
		// le noeud courant et le noeud de départ
		let currentNode = nodeFrom;
		
		// tant que le noeud courant n'est pas le noeud à atteindre
		// rechercher, qualifier et placer dans la liste ouverte les noeuds adjacents au noeud courant 
		// rechercher le meilleur noeud de la liste ouvert et le placer dans la liste fermée
		// faire de ce noeud le noeud courant pour continuer l'exploration
        while ( currentNode.x !== nodeTo.x || currentNode.y !== nodeTo.y ) {
           this.listNextCellsAndPushToOpenedList(currentNode,this.map,nodeTo,lastBestNode);
           lastBestNode = this.searchBestNodeInOpenedListAndPushItToClosedList();
           currentNode = lastBestNode;
        }
       
        nodeFrom = this.closedList[0]; 

        let elt = this.closedList[this.closedList.length - 1];
        while ( elt.x !== nodeFrom.x || elt.y !== nodeFrom.y ) {
             elt = elt.parent;
             this.path.push(elt);
         }

         this.path = this.path.reverse();
    }
}












	