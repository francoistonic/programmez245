 "use strict";

 const createCanvasContext = function(name, width, height, zindex, htmlElement, color) {
  let canvas = window.document.createElement("canvas");
  canvas.id = name;
  canvas.style.position = "absolute";
  if ( color != undefined )
   canvas.style.background = color;
  canvas.style.zIndex = zindex;
  canvas.width = width;
  canvas.height = height;
  if ( htmlElement != undefined )
   htmlElement.appendChild(canvas.getContext('2d').canvas);
  return canvas.getContext('2d');
 }
 
 const clearCanvas = function(name, canvasContext) {
  let canvas = document.getElementById(name);
  canvasContext.clearRect(0, 0, canvas.width, canvas.height);
 }
 
 const initGameGrid = function(mapLabyrinth,gameCanvasContext) {
  let player = {};
  let computer = {};
  for(let i in mapLabyrinth)  {
   let line = mapLabyrinth[i];
   let element = line.split("");
   for(let j in element)  {
    if ( element[ j ] == "#" ) {
     showWall(gameCanvasContext,j,i);
    } else if ( element[ j ] === "C" ) {
     showComputer(gameCanvasContext,j,i);
	   computer.x = parseInt(j);
	   computer.y = parseInt(i);
     element[ j ] = " ";
    } else if ( element[ j ] === "P" ) {
     showPlayer(gameCanvasContext,j,i);
	   player.x = parseInt(j);
	   player.y = parseInt(i);
     element[ j ] = " ";
    }
   }
  }
  return {
      player : {
        x : player.x,
        y : player.y
      },

      computer : {
        x : computer.x,
        y : computer.y
      }
  }
 };

 const showSquare = function(canvasContext,color,x,y) {
  canvasContext.beginPath();
  canvasContext.rect(x*10,y*10,10,10);
  canvasContext.fillStyle = color;
  canvasContext.fill();
  canvasContext.stroke();
 }
 
 const showWall = function(canvasContext,x,y) {
  showSquare(canvasContext,"grey",x,y);
 }
 
 const showPlayer = function(canvasContext,x,y) {
  showSquare(canvasContext,"yellow",x,y);
 }
 
 const showComputer = function(canvasContext,x,y) {
  showSquare(canvasContext,"red",x,y);
 }

 const showPath = function(canvasContext,x,y) {
    showSquare(canvasContext,"green",x,y);
 }
 
 const displayLabyrinth = function(mapLabyrinth,gameCanvasContext) {
  for(let i in mapLabyrinth)  {
   let line = mapLabyrinth[i];
   let element = line.split("");
   for(let j in element)  {
    if ( element[ j ] === "#" ) {
     showWall(gameCanvasContext,j,i);
    } 
   }
  }
 };
 
